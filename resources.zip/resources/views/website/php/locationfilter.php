<?php include('header.php'); ?>
<?php include('nav.php'); ?>
<section id="locationSearch" class="locationSearch" role="location Filter">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="searchlocate">
                    <form action="/action_page.php" class="searchLocationForm">
                        <div class="input-group">
                            <input type="text" class="form-control" name="Search" placeholder="Search">

                            <button type="button" class="  btn locateMeicon"> 
                                <i class="flaticon-aim"></i> Locate Me
                            </button>

                            <span class="input-group-btn">
                                <button class="filter btn btn-primary" type="button">Filter</button>
                            </span>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="postWall" class="postWall" role="post wall" style="background-image:url(images/backimg2.png)">
    <div class="container">
        <div class="row">
            <div class="col-md-6 ">
                <div class="sandeshBox" style="background-image:url(images/backimg1.png)">
                    <div class="d-flex">
                        <img src="images/sandeshimg1.png" alt="" class="img-fluid">
                        <div class="sandeshpara">
                            <h6>25 - 08 - 2021 </h6>
                            <p class="text-bold">Full name</p>
                            <p>Lorem ipsum dolor sit amet, labores nostrum eam te. Lorem ipsum dolor sit amet, labores
                                nostrum
                                eam te. Lorem ipsum dolor sit amet, labores nostrum eam te. Lorem ipsum dolor sit amet,
                                labores
                                nostrum eam te.Lorem ipsum dolor sit amet.
                            </p>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between">
                        <a href="#" class="sandeshone">Approved</a>
                        <a href="#" class="sandeshone">Delete / Edit</a>

                    </div>
                </div>
            </div>
            <div class="col-md-6 ">
                <div class="sandeshBox" style="background-image:url(images/backimg1.png)">
                    <div class="d-flex">
                        <img src="images/sandeshimg1.png" alt="" class="img-fluid">
                        <div class="sandeshpara">
                            <h6>25 - 08 - 2021 </h6>
                            <p class="text-bold">Full name</p>
                            <p>Lorem ipsum dolor sit amet, labores nostrum eam te. Lorem ipsum dolor sit amet, labores
                                nostrum
                                eam te. Lorem ipsum dolor sit amet, labores nostrum eam te. Lorem ipsum dolor sit amet,
                                labores
                                nostrum eam te.Lorem ipsum dolor sit amet.
                            </p>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between">
                        <a href="#" class="sandeshone">Approved</a>
                        <a href="#" class="sandeshone">Delete / Edit</a>

                    </div>
                </div>
            </div>
            <div class="col-md-6 ">
                <div class="sandeshBox" style="background-image:url(images/backimg1.png)">
                    <div class="d-flex">
                        <img src="images/sandeshimg1.png" alt="" class="img-fluid">
                        <div class="sandeshpara">
                            <h6>25 - 08 - 2021 </h6>
                            <p class="text-bold">Full name</p>
                            <p>Lorem ipsum dolor sit amet, labores nostrum eam te. Lorem ipsum dolor sit amet, labores
                                nostrum
                                eam te. Lorem ipsum dolor sit amet, labores nostrum eam te. Lorem ipsum dolor sit amet,
                                labores
                                nostrum eam te.Lorem ipsum dolor sit amet.
                            </p>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between">
                        <a href="#" class="sandeshone">Approved</a>
                        <a href="#" class="sandeshone">Delete / Edit</a>

                    </div>
                </div>
            </div>
            <div class="col-md-6 ">
                <div class="sandeshBox" style="background-image:url(images/backimg1.png)">
                    <div class="d-flex">
                        <img src="images/sandeshimg1.png" alt="" class="img-fluid">
                        <div class="sandeshpara">
                            <h6>25 - 08 - 2021 </h6>
                            <p class="text-bold">Full name</p>
                            <p>Lorem ipsum dolor sit amet, labores nostrum eam te. Lorem ipsum dolor sit amet, labores
                                nostrum
                                eam te. Lorem ipsum dolor sit amet, labores nostrum eam te. Lorem ipsum dolor sit amet,
                                labores
                                nostrum eam te.Lorem ipsum dolor sit amet.
                            </p>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between">
                        <a href="#" class="sandeshone">Approved</a>
                        <a href="#" class="sandeshone">Delete / Edit</a>

                    </div>
                </div>
            </div>
            <div class="col-md-6 ">
                <div class="sandeshBox" style="background-image:url(images/backimg1.png)">
                    <div class="d-flex">
                        <img src="images/sandeshimg1.png" alt="" class="img-fluid">
                        <div class="sandeshpara">
                            <h6>25 - 08 - 2021 </h6>
                            <p class="text-bold">Full name</p>
                            <p>Lorem ipsum dolor sit amet, labores nostrum eam te. Lorem ipsum dolor sit amet, labores
                                nostrum
                                eam te. Lorem ipsum dolor sit amet, labores nostrum eam te. Lorem ipsum dolor sit amet,
                                labores
                                nostrum eam te.Lorem ipsum dolor sit amet.
                            </p>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between">
                        <a href="#" class="sandeshone">Approved</a>
                        <a href="#" class="sandeshone">Delete / Edit</a>

                    </div>
                </div>
            </div>
            <div class="col-md-6 ">
                <div class="sandeshBox" style="background-image:url(images/backimg1.png)">
                    <div class="d-flex">
                        <img src="images/sandeshimg1.png" alt="" class="img-fluid">
                        <div class="sandeshpara">
                            <h6>25 - 08 - 2021 </h6>
                            <p class="text-bold">Full name</p>
                            <p>Lorem ipsum dolor sit amet, labores nostrum eam te. Lorem ipsum dolor sit amet, labores
                                nostrum
                                eam te. Lorem ipsum dolor sit amet, labores nostrum eam te. Lorem ipsum dolor sit amet,
                                labores
                                nostrum eam te.Lorem ipsum dolor sit amet.
                            </p>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between">
                        <a href="#" class="sandeshone">Approved</a>
                        <a href="#" class="sandeshone">Delete / Edit</a>

                    </div>
                </div>
            </div>
            <div class="col-md-6 ">
                <div class="sandeshBox" style="background-image:url(images/backimg1.png)">
                    <div class="d-flex">
                        <img src="images/sandeshimg1.png" alt="" class="img-fluid">
                        <div class="sandeshpara">
                            <h6>25 - 08 - 2021 </h6>
                            <p class="text-bold">Full name</p>
                            <p>Lorem ipsum dolor sit amet, labores nostrum eam te. Lorem ipsum dolor sit amet, labores
                                nostrum
                                eam te. Lorem ipsum dolor sit amet, labores nostrum eam te. Lorem ipsum dolor sit amet,
                                labores
                                nostrum eam te.Lorem ipsum dolor sit amet.
                            </p>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between">
                        <a href="#" class="sandeshone">Approved</a>
                        <a href="#" class="sandeshone">Delete / Edit</a>

                    </div>
                </div>
            </div>
            <div class="col-md-6 ">
                <div class="sandeshBox" style="background-image:url(images/backimg1.png)">
                    <div class="d-flex">
                        <img src="images/sandeshimg1.png" alt="" class="img-fluid">
                        <div class="sandeshpara">
                            <h6>25 - 08 - 2021 </h6>
                            <p class="text-bold">Full name</p>
                            <p>Lorem ipsum dolor sit amet, labores nostrum eam te. Lorem ipsum dolor sit amet, labores
                                nostrum
                                eam te. Lorem ipsum dolor sit amet, labores nostrum eam te. Lorem ipsum dolor sit amet,
                                labores
                                nostrum eam te.Lorem ipsum dolor sit amet.
                            </p>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between">
                        <a href="#" class="sandeshone">Approved</a>
                        <a href="#" class="sandeshone">Delete / Edit</a>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="paginationPage" section class="paginationPage" role="pagination">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="paginationPara">
                    <ul class="pagination justify-content-center">
                        <li class="page-item"><a class="page-link" href="#"><i class="fa fa-angle-left"
                                    aria-hidden="true"></i></a></li>
                        <li class="page-item"><a class="page-link" href="#">01</a></li>
                        <li class="page-item"><a class="page-link" href="#">02</a></li>
                        <li class="page-item"><a class="page-link" href="#">03</a></li>
                        <li class="page-item"><a class="page-link" href="#">04</a></li>
                        <li class="page-item"><a class="page-link" href="#">05</a></li>
                        <li class="page-item"><a class="page-link" href="#">06</a></li>
                        <li class="page-item"><a class="page-link" href="#"><i class="fa fa-angle-right"
                                    aria-hidden="true"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    </div>
</section>
<?php include('footer.php'); ?>