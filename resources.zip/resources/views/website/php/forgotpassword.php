<?php include('header.php'); ?>
<?php include('nav.php'); ?>
<section id="forgotPassword" class="forgotPassword" role="forgot password">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="forgotPage">
                    <button class="close1"><i class="flaticon-cancel"></i></button>
                    <h3>Forgot password</h3>
                    <p>We have sent you an OTP on</p>
                    <form action="/action_page.php" class="formForgot">
                        <div class="input-group mb-4">
                            <input type="Number" class="form-control" placeholder="Enter phone number" aria-label="Enter phone number"
                                aria-describedby="basic-addon1">
                        </div>
                        <button class="Loginbtn">Send OTP</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>